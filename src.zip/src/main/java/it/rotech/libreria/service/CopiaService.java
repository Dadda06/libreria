package it.rotech.libreria.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import it.rotech.libreria.dto.CopiaDTO;
import it.rotech.libreria.dto.Request.CopiaRequest;
import it.rotech.libreria.exception.CasaEditriceNotFoundException;
import it.rotech.libreria.exception.CopiaNotFoundException;
import it.rotech.libreria.exception.LibroNotFoundException;
import it.rotech.libreria.model.CasaEditrice;
import it.rotech.libreria.model.Copia;
import it.rotech.libreria.model.Libro;
import it.rotech.libreria.repository.CasaEditriceRepository;
import it.rotech.libreria.repository.CopiaRepository;
import it.rotech.libreria.repository.LibroRepository;
import it.rotech.libreria.utily.Mapper;

@Service 
public class CopiaService {
    private final CopiaRepository copiaRepository;
    private final Mapper mapper;
    private final LibroRepository libroRepository;
    private final CasaEditriceRepository casaEditriceRepository;

    public CopiaService (CopiaRepository copiaRepository, Mapper mapper, LibroRepository libroRepository, CasaEditriceRepository casaEditriceRepository) {
        this.copiaRepository=copiaRepository;
        this.mapper=mapper;
        this.libroRepository=libroRepository;
        this.casaEditriceRepository=casaEditriceRepository;
    }

    public List<CopiaDTO> findAllCopie(){
        List <Copia> risultato = copiaRepository.findAll();
        List <CopiaDTO> risultatoDTO = new ArrayList<>();
        for (Copia copia : risultato){
            risultatoDTO.add(mapper.convertCopiaToCopiaDTO(copia));
        }
        return risultatoDTO;
    }

    public CopiaDTO findById (Integer id){
        Copia copia = copiaRepository.findById(id)
            .orElseThrow(() -> new CopiaNotFoundException("Copie non trovato con ID: " + id));
        return mapper.convertCopiaToCopiaDTO(copia);
    }

     public CopiaDTO addCopia (CopiaRequest copiaRequest){
        Integer numCopie= copiaRequest.getNumCopie();
        Integer idlibro= copiaRequest.getidLibro();
        String casa= copiaRequest.getCasa();
        Libro libro = libroRepository.findById(idlibro).orElseThrow(()-> new LibroNotFoundException("Libro non esistente!"));
        List <CasaEditrice> casaDB = casaEditriceRepository.findAllByNome(casa);
            if (casaDB.isEmpty())
            throw new CasaEditriceNotFoundException("Casa Editrice non trovata, creare prima la Casa!");

        Copia copiaSalvata = new Copia(numCopie, libro, casaDB.getLast());
        return mapper.convertCopiaToCopiaDTO(copiaRepository.save(copiaSalvata));
     }

    public CopiaDTO updateCopia (CopiaRequest copiaRequest, Integer id) {
        Integer numCopie= copiaRequest.getNumCopie();
        Integer idlibro= copiaRequest.getidLibro();
        String casa= copiaRequest.getCasa();
        Copia copia=copiaRepository.findById(id).orElseThrow(()-> new CopiaNotFoundException("Copia non esistente"));
        copia.setNumeroCopie(numCopie);
        copia.setLibro(libroRepository.findById(idlibro).orElseThrow(()-> new LibroNotFoundException("Libro non trovato!")));
        copia.setCasaEditrice(casaEditriceRepository.findAllByNome(casa).getLast());
        return mapper.convertCopiaToCopiaDTO(copiaRepository.save(copia));
    }

    public void deleteCopia (Integer id){
        copiaRepository.deleteById(id);
    }
}
