package it.rotech.libreria.service;

import org.jspecify.annotations.Nullable;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import it.rotech.libreria.dto.Request.LoginRequest;
import it.rotech.libreria.exception.LoginNotFoundException;
import it.rotech.libreria.model.Login;
import it.rotech.libreria.repository.LoginRepository;

@Service 
public class LoginService {

    private final LoginRepository loginRepository;
    
    private final AuthenticationManager authenticationManager;
    public LoginService (LoginRepository loginRepository,AuthenticationManager authenticationManager){
        this.loginRepository=loginRepository;
        this.authenticationManager = authenticationManager;
    }

    // public boolean verificaLogin(String username, String passwordInserita){
    //     // Login utenteTrovato= loginRepository.findByUsername(username);
        
    //     if(utenteTrovato == null){
    //         return false;
    //     }

    //     if(utenteTrovato.getPassword().equals(passwordInserita)){
    //         return true;
    //     }
    //     return false;
    // }



    public String login(LoginRequest richiesta) {
        // TODO Auto-generated method stub
        Authentication authentication = new UsernamePasswordAuthenticationToken(richiesta.getUsername(), richiesta.getPassword());
        authenticationManager.authenticate(authentication);
        return "Sei autenticato";
    }
   
}
